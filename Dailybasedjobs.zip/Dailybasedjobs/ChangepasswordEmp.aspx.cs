﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Dailybasedjobs
{
    public partial class ChangepasswordEmp : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DailyJobs"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ida"] != null)
            {
                if (!IsPostBack)
                {

                }
            }
            else
            {
                Response.Redirect("Index.aspx");
            }
        }

        protected void updt_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update admin set password='" + txtop.Text + "' where password='" + txtcnp.Text + "' ", con);
            cmd.ExecuteNonQuery();
            con.Close();
            lbl.Text = "password successfully changed";
        }
    }
}